#!/bin/bash
echo 'saldırmak istediğiniz adresi giriniz'
read pin
ping $pin
